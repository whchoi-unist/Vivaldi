import os
import sys
VIVALDI_PATH = os.environ.get('vivaldi_path')+'/'
sys.path.append(VIVALDI_PATH + "/translator")

